nj-react-mst-boilerplate
====

> `NornJ`+`React`+`Mobx-state-tree`项目模板，可以此项目为模板快速创建新项目。

## 构建命令

```sh
npm run dev-web         #启动node端本地调试server，然后使用http://localhost:8080/dist/web访问页面
npm run build-web       #构建生产代码到dist目录
npm run build-web-test  #构建生产代码到dist目录，使用测试环境配置
```

#{learningGuide}#