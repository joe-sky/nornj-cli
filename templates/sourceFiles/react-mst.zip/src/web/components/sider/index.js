﻿import comp from './sider';
export default comp;