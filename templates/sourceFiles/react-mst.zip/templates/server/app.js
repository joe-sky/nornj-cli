﻿const #{pageName}# = require('./routes/#{pageName}#');
app.use('/#{pageName}#', #{pageName}#);

//{pages}//