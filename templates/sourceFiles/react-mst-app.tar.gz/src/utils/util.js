export function capitalize(str) {
  return str[0].toUpperCase() + str.substr(1);
}
