module.exports = {
  'brand-primary': '#152941',
  'brand-primary-tap': '#233b58'
};
