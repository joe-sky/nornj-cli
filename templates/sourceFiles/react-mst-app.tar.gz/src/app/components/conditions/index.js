﻿import comp from './conditions.jsx';
export default comp;