﻿import comp from './header.jsx';
export default comp;