﻿import comp from './funcIcon.jsx';
export default comp;