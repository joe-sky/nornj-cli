﻿import comp from './#{componentName | capitalize}#';
export default comp;