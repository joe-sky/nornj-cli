﻿import comp from './#{componentName | capitalize}#.jsx';
export default comp;