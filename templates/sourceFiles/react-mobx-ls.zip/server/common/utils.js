'use strict';

const resultData = {
  success: true,
  msg: null,
  data: null
};

module.exports = {
  resultData
};