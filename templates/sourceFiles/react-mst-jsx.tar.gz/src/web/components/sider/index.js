﻿import comp from './sider.jsx';
export default comp;