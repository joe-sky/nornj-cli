nornj-react-mst-boilerplate
====

> `NornJ`+`React`+`Mobx-state-tree`项目模板，可以此项目为模板快速创建新项目。

## 构建命令

```sh
npm run dev 或 npm start  #启动webpack-dev-server本地调试，接口使用本地mock server，然后使用http://localhost:8080/dist/访问页面
npm run build             #构建生产代码到dist目录
npm run build-test        #构建生产代码到dist目录，使用测试环境配置
npm test                  #运行单元测试
npm run coverage          #生成单元测试覆盖率报告
npm e2e                   #运行e2e测试
```

{{%learningGuide%}}