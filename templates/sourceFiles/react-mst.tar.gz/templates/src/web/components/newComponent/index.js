﻿import comp from './#{componentName | pascal}#';
export default comp;