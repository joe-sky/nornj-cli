const resultData = {
  success: true,  //是否成功
  message: null,  //错误信息
  data: null      //返回数据，可以是任意结构
};

module.exports = {
  resultData
};
