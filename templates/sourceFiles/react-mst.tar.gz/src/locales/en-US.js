const enUS = {
  roleManage: 'Role Manage',
  roleName: 'Role Name',
};

export default enUS;