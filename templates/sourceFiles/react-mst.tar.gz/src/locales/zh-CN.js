const zhCN = {
  roleManage: '角色管理',
  roleName: '角色名称',
};

export default zhCN;