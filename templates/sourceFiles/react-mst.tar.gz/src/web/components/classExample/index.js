﻿import comp from './ClassExample.jsx';
export default comp;