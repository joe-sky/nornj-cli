﻿import comp from './header';
export default comp;