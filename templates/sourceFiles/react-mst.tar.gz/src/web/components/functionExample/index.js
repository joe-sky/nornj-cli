﻿import comp from './FunctionExample.jsx';
export default comp;