declare module '*.less';
declare module '*.scss';
declare module '*.css';
declare module 'echarts/lib/*';
declare module 'moment/locale/*';
