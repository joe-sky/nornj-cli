// 所有没有@types定义的第三方库，在此处定义
declare module '*.less';
declare module '*.scss';
declare module '*.css';
declare module 'echarts/lib/*';
