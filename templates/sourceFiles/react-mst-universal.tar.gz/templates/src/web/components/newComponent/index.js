﻿import comp from './#{componentName | pascal}#.jsx';
export default comp;